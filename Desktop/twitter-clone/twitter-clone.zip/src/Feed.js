import React from 'react'
import './Feed.css';
import TweetBox from './TweetBox';
import Post from './Post'


function Feed() {
 return (
  <div className="feed">
   {/* header */}
   <div className="feed_header">
   <h2>Home</h2>
   </div>
   {/* TweetBox */}
   < TweetBox />
   {/* Tweet Post */}
   <Post displayName="Gaps Reuel" username="reuwelscode" verified={true} text="WOWWWW it's working" 
   avatar="https://i.pinimg.com/736x/1b/7a/87/1b7a87815254a8e789e812ba34df03d0.jpg" 
   image="https://i.pinimg.com/736x/1b/7a/87/1b7a87815254a8e789e812ba34df03d0.jpg"/>
   <Post />
   <Post />
   <Post />
   

  </div>
 )
}

export default Feed
